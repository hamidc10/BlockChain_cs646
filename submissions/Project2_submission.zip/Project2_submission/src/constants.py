# We (Hamid, Chantel, Vira, Trey, Xavier) declare that we have completed this computer code in accordance with the UAB Academic Integrity Code and the UAB CS Honor Code.
# We have read the UAB Academic Integrity Code and understand that any breach of the Code may result in severe penalties.
# Student initials: HC, CRW, VVS, TC, XM
# Date: 10/1/23
keys_folder = "./public_keys/"
blocks_folder = "./blocks/"
pending_transactions_folder = "./pending/"
processed_transactions_folder = "./processed/"
wallet_skeleton = "./wallet_skeleton.py"
account_state_file_path = "./account_state.json"
